# Warp Connect v0.3.1 test

Purpose: verify clean MASQUE teardown before WireGuard starts.

Changes from v0.3:
- remove double MASQUE stop path
- mark manual stop before native shutdown so restart watchdog cannot race teardown
- wait for UsqueVpnService to be fully destroyed
- 500 ms Android VPN settle delay before WireGuard
- do not double-close the TUN fd after ownership was transferred to native Usque
- WireGuard backend/lifecycle unchanged from v0.3 stable v1.5 baseline

Test sequence:
1. Fresh launch -> WireGuard connect/disconnect/connect.
2. MASQUE connect -> disconnect.
3. Select WireGuard -> connect/disconnect/connect.
