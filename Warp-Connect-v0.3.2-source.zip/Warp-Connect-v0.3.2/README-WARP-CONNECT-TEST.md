# Warp Connect v0.3.2 test

Baseline: Warp Connect v0.3.0.

Only behavioral change:
- restores the v0.3.0 MASQUE disconnect path unchanged;
- records when MASQUE teardown returns to the UI;
- enforces a fixed 1.8 second settle window before WireGuard connect if MASQUE was just used.

WireGuard connect/disconnect code remains the stable v1.5-style lifecycle path.

Test order:
1. WireGuard connect/disconnect/connect before MASQUE.
2. MASQUE connect/disconnect.
3. Immediately select WireGuard and connect.
