package com.iknalos.warpgo

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import usqueandroid.Usqueandroid
import java.io.File

/**
 * Warp Connect clean baseline.
 *
 * WireGuard connect/disconnect intentionally follows the known-good Warp Go TV v1.5
 * AppCompatActivity + lifecycleScope flow. MASQUE is added alongside it as a separate
 * transport; there are no task/foreground/singleTask workarounds in this build.
 */
class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("warp_connect", MODE_PRIVATE) }
    private val configFile by lazy { File(filesDir, "usque-config.json") }

    private var lastMasqueDisconnectAt = 0L
    private var busy = false
    private var pendingProtocol: String? = null

    private lateinit var statusDot: TextView
    private lateinit var statusText: TextView
    private lateinit var detailText: TextView
    private lateinit var connectButton: TextView
    private lateinit var protocolGroup: RadioGroup
    private lateinit var masqueRadio: RadioButton
    private lateinit var wireGuardRadio: RadioButton
    private lateinit var portSection: LinearLayout
    private lateinit var portGroup: RadioGroup
    private lateinit var port4500: RadioButton
    private lateinit var port2408: RadioButton
    private lateinit var port500: RadioButton

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                startSelected()
            } else {
                busy = false
                pendingProtocol = null
                toast("VPN permission was not granted")
                refreshState()
            }
        }

    private val ticker = object : Runnable {
        override fun run() {
            refreshState()
            handler.postDelayed(this, 750L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreChoice()
        refreshState()
        handler.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        if (::connectButton.isInitialized) refreshState()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(26))
            setBackgroundColor(Color.rgb(5, 12, 27))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        // New Warp Connect branding. A compact height keeps it usable on TV and foldables.
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.warp_connect_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "Warp Connect"
        }, LinearLayout.LayoutParams(-1, dp(150)).apply { bottomMargin = dp(4) })

        val statusCard = card()
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        statusDot = TextView(this).apply {
            text = "●"
            textSize = 22f
            setPadding(0, 0, dp(10), 0)
        }
        statusText = TextView(this).apply {
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        }
        statusRow.addView(statusDot)
        statusRow.addView(statusText)
        statusCard.addView(statusRow, lp(-1, -2))

        detailText = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(148, 163, 184))
            setPadding(0, dp(7), 0, 0)
        }
        statusCard.addView(detailText, lp(-1, -2))
        root.addView(statusCard, spacedLp())

        val protocolCard = card()
        protocolCard.addView(sectionTitle("Protocol"), lp(-1, -2))
        protocolGroup = RadioGroup(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(7), 0, 0)
        }
        masqueRadio = protocolRadio("MASQUE")
        wireGuardRadio = protocolRadio("WireGuard")
        protocolGroup.addView(masqueRadio, LinearLayout.LayoutParams(0, dp(50), 1f))
        protocolGroup.addView(wireGuardRadio, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(10) })
        protocolCard.addView(protocolGroup, lp(-1, -2))
        root.addView(protocolCard, spacedLp())

        portSection = card().apply {
            addView(sectionTitle("WireGuard port"), lp(-1, -2))
        }
        portGroup = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        port4500 = smallRadio("4500")
        port2408 = smallRadio("2408")
        port500 = smallRadio("500")
        portGroup.addView(port4500, LinearLayout.LayoutParams(0, dp(46), 1f))
        portGroup.addView(port2408, LinearLayout.LayoutParams(0, dp(46), 1f))
        portGroup.addView(port500, LinearLayout.LayoutParams(0, dp(46), 1f))
        portSection.addView(portGroup, lp(-1, -2))
        root.addView(portSection, spacedLp())

        connectButton = TextView(this).apply {
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            minHeight = dp(68)
            setPadding(dp(20), dp(16), dp(20), dp(16))
            setOnClickListener { onToggle() }
            setOnFocusChangeListener { _, focused -> updateConnectStyle(focused) }
        }
        root.addView(connectButton, spacedLp())

        root.addView(TextView(this).apply {
            text = "Test v0.3.2 · stable WireGuard + MASQUE settle guard"
            textSize = 10.5f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(100, 116, 139))
            setPadding(0, dp(10), 0, 0)
        }, lp(-1, -2))

        protocolGroup.setOnCheckedChangeListener { _, _ ->
            if (!busy && !anyConnected()) {
                prefs.edit().putString("protocol", selectedProtocol()).apply()
                updateProtocolUi()
                refreshState()
            }
        }
        portGroup.setOnCheckedChangeListener { _, _ ->
            prefs.edit().putInt("port", selectedPort()).apply()
        }

        setContentView(scroll)
        connectButton.requestFocus()
    }

    private fun restoreChoice() {
        if (prefs.getString("protocol", "masque") == "wireguard") {
            wireGuardRadio.isChecked = true
        } else {
            masqueRadio.isChecked = true
        }
        when (prefs.getInt("port", 4500)) {
            2408 -> port2408.isChecked = true
            500 -> port500.isChecked = true
            else -> port4500.isChecked = true
        }
        updateProtocolUi()
    }

    private fun selectedProtocol(): String = if (wireGuardRadio.isChecked) "wireguard" else "masque"

    private fun selectedPort(): Int = when (portGroup.checkedRadioButtonId) {
        port2408.id -> 2408
        port500.id -> 500
        else -> 4500
    }

    private fun updateProtocolUi() {
        portSection.visibility = if (selectedProtocol() == "wireguard") View.VISIBLE else View.GONE
    }

    private fun anyConnected(): Boolean = WarpManager.isUp(this) || UsqueVpnService.isTunnelActive()

    private fun onToggle() {
        if (busy) return
        if (anyConnected()) {
            if (WarpManager.isUp(this)) disconnectWireGuard() else disconnectMasque()
            return
        }

        busy = true
        pendingProtocol = selectedProtocol()
        refreshState()
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startSelected()
    }

    private fun startSelected() {
        when (pendingProtocol ?: selectedProtocol()) {
            "wireguard" -> doConnectWireGuard()
            else -> doConnectMasque()
        }
    }

    /** Exact v1.5 connection structure: lifecycleScope + Dispatchers.IO + WarpManager.connect. */
    private fun doConnectWireGuard() {
        val port = selectedPort()
        prefs.edit().putInt("port", port).apply()
        lifecycleScope.launch {
            try {
                // Keep the stable v1.5 WireGuard connect path unchanged, but if MASQUE
                // was just stopped, allow Android a short fixed settle window first.
                val sinceMasqueStop = SystemClock.elapsedRealtime() - lastMasqueDisconnectAt
                if (lastMasqueDisconnectAt > 0L && sinceMasqueStop < MASQUE_TO_WIREGUARD_SETTLE_MS) {
                    delay(MASQUE_TO_WIREGUARD_SETTLE_MS - sinceMasqueStop)
                }
                withContext(Dispatchers.IO) {
                    WarpManager.connect(applicationContext, port)
                }
            } catch (e: Exception) {
                toast("WireGuard failed: ${e.message ?: "unknown error"}")
            } finally {
                busy = false
                pendingProtocol = null
                refreshState()
                connectButton.requestFocus()
            }
        }
    }

    /** Exact v1.5 disconnection structure. */
    private fun disconnectWireGuard() {
        busy = true
        refreshState()
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    WarpManager.disconnect(applicationContext)
                }
            } catch (e: Exception) {
                toast("WireGuard disconnect failed: ${e.message ?: "unknown error"}")
            } finally {
                busy = false
                refreshState()
                connectButton.requestFocus()
            }
        }
    }

    private fun validUsqueRegistration(): Boolean =
        configFile.exists() && runCatching { Usqueandroid.isRegistered(configFile.absolutePath) }.getOrDefault(false)

    private fun doConnectMasque() {
        lifecycleScope.launch {
            try {
                if (!validUsqueRegistration()) {
                    val err = withContext(Dispatchers.IO) {
                        if (configFile.exists()) configFile.delete()
                        Usqueandroid.register(configFile.absolutePath, "Android")
                    }
                    if (!err.isNullOrBlank() || !validUsqueRegistration()) {
                        throw IllegalStateException(err.ifBlank { "registration did not complete" })
                    }
                }
                val endpoint = runCatching { Usqueandroid.getDefaultEndpoint(configFile.absolutePath) }
                    .getOrNull().orEmpty().ifBlank { "162.159.198.2:500" }
                startService(
                    Intent(this@MainActivity, UsqueVpnService::class.java)
                        .putExtra("configPath", configFile.absolutePath)
                        .putExtra("sni", "www.visa.cn")
                        .putExtra("endpoint", endpoint)
                        .putExtra("splitMode", false)
                )
            } catch (e: Exception) {
                toast("MASQUE failed: ${e.message ?: "unknown error"}")
            } finally {
                busy = false
                pendingProtocol = null
                refreshState()
                connectButton.requestFocus()
            }
        }
    }

    private fun disconnectMasque() {
        busy = true
        refreshState()
        UsqueVpnService.stopActiveTunnel()
        runCatching {
            startService(Intent(this, UsqueVpnService::class.java).setAction(UsqueVpnService.ACTION_STOP))
        }
        handler.postDelayed({
            // Preserve the v0.3 MASQUE stop path that actually disconnects.
            // Record when the UI sees teardown complete, then let WireGuard enforce
            // the additional fixed settle window if selected next.
            lastMasqueDisconnectAt = SystemClock.elapsedRealtime()
            busy = false
            refreshState()
            connectButton.requestFocus()
        }, 400L)
    }

    private fun refreshState() {
        if (!::statusText.isInitialized) return
        val wg = WarpManager.isUp(this)
        val mqConnected = UsqueVpnService.isTunnelConnected()
        val mqActive = UsqueVpnService.isTunnelActive()
        val connected = wg || mqConnected
        val connecting = busy || (mqActive && !mqConnected)

        statusDot.setTextColor(
            when {
                connected -> Color.rgb(52, 211, 153)
                connecting -> Color.rgb(251, 191, 36)
                else -> Color.rgb(248, 113, 113)
            }
        )
        statusText.text = when {
            connected -> "Connected"
            connecting -> "Connecting…"
            else -> "Disconnected"
        }
        detailText.text = when {
            wg -> "WireGuard · port ${selectedPort()}"
            mqConnected -> "MASQUE · ${UsqueVpnService.currentEndpoint()}"
            mqActive -> "MASQUE tunnel starting"
            else -> "Ready · ${if (selectedProtocol() == "masque") "MASQUE" else "WireGuard"} selected"
        }
        connectButton.text = if (wg || mqActive || mqConnected) "DISCONNECT" else "CONNECT"

        val allowProtocolChange = !anyConnected() && !busy
        protocolGroup.isEnabled = allowProtocolChange
        masqueRadio.isEnabled = allowProtocolChange
        wireGuardRadio.isEnabled = allowProtocolChange
        port4500.isEnabled = allowProtocolChange
        port2408.isEnabled = allowProtocolChange
        port500.isEnabled = allowProtocolChange
        updateConnectStyle(connectButton.hasFocus())
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(14))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.rgb(15, 23, 42))
            setStroke(dp(1), Color.rgb(51, 65, 85))
        }
    }

    private fun sectionTitle(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 16f
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun protocolRadio(textValue: String): RadioButton = RadioButton(this).apply {
        text = textValue
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        isFocusable = true
        setPadding(dp(8), 0, dp(8), 0)
    }

    private fun smallRadio(textValue: String): RadioButton = RadioButton(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        isFocusable = true
    }

    private fun updateConnectStyle(focused: Boolean) {
        if (!::connectButton.isInitialized) return
        connectButton.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(if (anyConnected()) Color.rgb(185, 28, 28) else Color.rgb(30, 64, 175))
            setStroke(
                dp(if (focused) 4 else 1),
                if (focused) Color.rgb(250, 204, 21) else Color.rgb(59, 130, 246)
            )
        }
    }

    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
    private fun spacedLp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(textValue: String) = Toast.makeText(this, textValue, Toast.LENGTH_LONG).show()

    companion object {
        private const val MASQUE_TO_WIREGUARD_SETTLE_MS = 1800L
    }

}
