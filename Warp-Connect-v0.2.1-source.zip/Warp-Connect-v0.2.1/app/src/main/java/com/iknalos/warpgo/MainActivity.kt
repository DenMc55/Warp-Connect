package com.iknalos.warpgo

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.wireguard.android.backend.Tunnel
import usqueandroid.Usqueandroid
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    companion object { private const val REQ_VPN = 2002 }

    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val configFile by lazy { File(filesDir, "usque-config.json") }
    private val prefs by lazy { getSharedPreferences("warp_connect", MODE_PRIVATE) }

    private lateinit var statusDot: TextView
    private lateinit var statusText: TextView
    private lateinit var detailText: TextView
    private lateinit var connectButton: TextView
    private lateinit var protocolGroup: RadioGroup
    private lateinit var masqueRadio: RadioButton
    private lateinit var wireGuardRadio: RadioButton
    private lateinit var portSection: LinearLayout
    private lateinit var portGroup: RadioGroup
    private lateinit var port4500: RadioButton
    private lateinit var port2408: RadioButton
    private lateinit var port500: RadioButton

    @Volatile private var busy = false
    @Volatile private var keepTaskFrontForWireGuard = false
    private var pendingProtocol: String? = null

    private val ticker = object : Runnable {
        override fun run() {
            refreshState()
            handler.postDelayed(this, 750)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreChoice()
        refreshState()
        handler.post(ticker)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(28))
            setBackgroundColor(Color.rgb(7, 15, 28))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }

        root.addView(TextView(this).apply {
            text = "Warp Connect"
            textSize = 32f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }, lp(-1, -2))
        root.addView(TextView(this).apply {
            text = "Cloudflare WARP · MASQUE + WireGuard"
            textSize = 14f
            setTextColor(Color.rgb(148, 163, 184))
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(16))
        }, lp(-1, -2))

        val statusCard = card()
        val statusRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        statusDot = TextView(this).apply { text = "●"; textSize = 22f; setPadding(0,0,dp(10),0) }
        statusText = TextView(this).apply { textSize = 21f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD) }
        statusRow.addView(statusDot); statusRow.addView(statusText)
        statusCard.addView(statusRow, lp(-1,-2))
        detailText = TextView(this).apply {
            textSize = 13f; setTextColor(Color.rgb(148,163,184)); setPadding(0,dp(7),0,0)
        }
        statusCard.addView(detailText, lp(-1,-2))
        root.addView(statusCard, spacedLp())

        val protoCard = card()
        protoCard.addView(sectionTitle("Protocol"), lp(-1,-2))
        protocolGroup = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0,dp(8),0,0) }
        masqueRadio = protocolRadio("MASQUE")
        wireGuardRadio = protocolRadio("WireGuard")
        protocolGroup.addView(masqueRadio, LinearLayout.LayoutParams(0,dp(52),1f))
        protocolGroup.addView(wireGuardRadio, LinearLayout.LayoutParams(0,dp(52),1f).apply { marginStart=dp(10) })
        protoCard.addView(protocolGroup, lp(-1,-2))
        root.addView(protoCard, spacedLp())

        portSection = card().apply {
            addView(sectionTitle("WireGuard port"), lp(-1,-2))
            addView(TextView(this@MainActivity).apply {
                text = "4500 is the normal choice. 2408 and 500 are alternatives for restrictive networks."
                textSize = 12f; setTextColor(Color.rgb(148,163,184)); setPadding(0,dp(3),0,dp(6))
            }, lp(-1,-2))
        }
        portGroup = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        port4500 = smallRadio("4500")
        port2408 = smallRadio("2408")
        port500 = smallRadio("500")
        portGroup.addView(port4500, LinearLayout.LayoutParams(0,dp(48),1f))
        portGroup.addView(port2408, LinearLayout.LayoutParams(0,dp(48),1f))
        portGroup.addView(port500, LinearLayout.LayoutParams(0,dp(48),1f))
        portSection.addView(portGroup, lp(-1,-2))
        root.addView(portSection, spacedLp())

        connectButton = TextView(this).apply {
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            minHeight = dp(68)
            setPadding(dp(20), dp(16), dp(20), dp(16))
            setOnClickListener { toggle() }
            setOnFocusChangeListener { _, focused -> updateConnectStyle(focused) }
        }
        root.addView(connectButton, spacedLp())

        root.addView(TextView(this).apply {
            text = "Test v0.2.1 · WireGuard activity guard"
            textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.rgb(100,116,139)); setPadding(0,dp(12),0,0)
        }, lp(-1,-2))

        protocolGroup.setOnCheckedChangeListener { _, _ ->
            if (!busy && !anyConnected()) {
                prefs.edit().putString("protocol", selectedProtocol()).apply()
                updateProtocolUi()
                refreshState()
            }
        }
        portGroup.setOnCheckedChangeListener { _, _ -> prefs.edit().putInt("port", selectedPort()).apply() }

        setContentView(scroll)
        connectButton.requestFocus()
    }

    private fun restoreChoice() {
        if (prefs.getString("protocol", "masque") == "wireguard") wireGuardRadio.isChecked = true else masqueRadio.isChecked = true
        when (prefs.getInt("port", 4500)) { 2408 -> port2408.isChecked=true; 500 -> port500.isChecked=true; else -> port4500.isChecked=true }
        updateProtocolUi()
    }

    private fun selectedProtocol() = if (wireGuardRadio.isChecked) "wireguard" else "masque"
    private fun selectedPort() = when (portGroup.checkedRadioButtonId) { port2408.id -> 2408; port500.id -> 500; else -> 4500 }

    private fun updateProtocolUi() {
        portSection.visibility = if (selectedProtocol()=="wireguard") View.VISIBLE else View.GONE
    }

    private fun anyConnected(): Boolean = UsqueVpnService.isTunnelActive() || WarpManager.isUp(this)

    private fun toggle() {
        if (busy) return
        if (anyConnected()) { disconnectAll(); return }
        busy = true
        pendingProtocol = selectedProtocol()
        refreshState()
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, REQ_VPN) else startSelected()
    }

    private fun startSelected() {
        when (pendingProtocol ?: selectedProtocol()) {
            "wireguard" -> startWireGuard()
            else -> startMasque()
        }
    }

    private fun startWireGuard() {
        val port = selectedPort()
        keepTaskFrontForWireGuard = true
        keepActivityVisibleDuringWireGuardStart()
        executor.execute {
            val result = runCatching { WarpManager.connect(applicationContext, port) }
            handler.post {
                busy=false; pendingProtocol=null
                if (result.isFailure) keepTaskFrontForWireGuard = false
                else handler.postDelayed({ keepTaskFrontForWireGuard = false }, 1800)
                if (result.isFailure) toast("WireGuard failed: ${result.exceptionOrNull()?.message ?: "unknown error"}")
                refreshState()
            }
        }
    }


    override fun onPause() {
        super.onPause()
        if (keepTaskFrontForWireGuard) keepActivityVisibleDuringWireGuardStart()
    }

    override fun onStop() {
        super.onStop()
        if (keepTaskFrontForWireGuard) keepActivityVisibleDuringWireGuardStart()
    }

    private fun keepActivityVisibleDuringWireGuardStart() {
        handler.postDelayed({
            if (!keepTaskFrontForWireGuard || isFinishing || isDestroyed) return@postDelayed
            runCatching {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                am.moveTaskToFront(taskId, 0)
            }
        }, 120)
        handler.postDelayed({
            if (!keepTaskFrontForWireGuard || isFinishing || isDestroyed) return@postDelayed
            runCatching {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                am.moveTaskToFront(taskId, 0)
            }
        }, 500)
    }

    private fun validUsqueRegistration(): Boolean = configFile.exists() && runCatching { Usqueandroid.isRegistered(configFile.absolutePath) }.getOrDefault(false)

    private fun startMasque() {
        if (!validUsqueRegistration()) {
            executor.execute {
                val result = runCatching {
                    if (configFile.exists()) configFile.delete()
                    Usqueandroid.register(configFile.absolutePath, "Android")
                }
                handler.post {
                    if (result.isSuccess && result.getOrNull().isNullOrBlank() && validUsqueRegistration()) launchMasque()
                    else {
                        busy=false; pendingProtocol=null
                        toast("MASQUE registration failed: ${result.exceptionOrNull()?.message ?: result.getOrNull().orEmpty()}")
                        refreshState()
                    }
                }
            }
        } else launchMasque()
    }

    private fun launchMasque() {
        val endpoint = runCatching { Usqueandroid.getDefaultEndpoint(configFile.absolutePath) }.getOrNull().orEmpty().ifBlank { "162.159.198.2:500" }
        startService(Intent(this, UsqueVpnService::class.java)
            .putExtra("configPath", configFile.absolutePath)
            .putExtra("sni", "www.visa.cn")
            .putExtra("endpoint", endpoint)
            .putExtra("splitMode", false))
        busy=false; pendingProtocol=null
        refreshState()
    }

    private fun disconnectAll() {
        busy=true
        executor.execute {
            runCatching { WarpManager.disconnect(applicationContext) }
            UsqueVpnService.stopActiveTunnel()
            runCatching { startService(Intent(this, UsqueVpnService::class.java).setAction(UsqueVpnService.ACTION_STOP)) }
            handler.postDelayed({ busy=false; refreshState() }, 400)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) startSelected()
        else if (requestCode == REQ_VPN) { busy=false; pendingProtocol=null; toast("VPN permission was not granted"); refreshState() }
    }

    private fun refreshState() {
        if (!::statusText.isInitialized) return
        val wg = WarpManager.isUp(this)
        val mqConnected = UsqueVpnService.isTunnelConnected()
        val mqActive = UsqueVpnService.isTunnelActive()
        val connected = wg || mqConnected
        val connecting = busy || (mqActive && !mqConnected)
        statusDot.setTextColor(when { connected -> Color.rgb(52,211,153); connecting -> Color.rgb(251,191,36); else -> Color.rgb(248,113,113) })
        statusText.text = when { connected -> "Connected"; connecting -> "Connecting…"; else -> "Disconnected" }
        detailText.text = when {
            wg -> "WireGuard · port ${selectedPort()}"
            mqConnected -> "MASQUE · ${UsqueVpnService.currentEndpoint()}"
            mqActive -> "MASQUE tunnel starting"
            else -> "Ready · ${if(selectedProtocol()=="masque") "MASQUE" else "WireGuard"} selected"
        }
        connectButton.text = if (wg || mqActive || mqConnected) "DISCONNECT" else "CONNECT"
        protocolGroup.isEnabled = !anyConnected() && !busy
        masqueRadio.isEnabled = !anyConnected() && !busy
        wireGuardRadio.isEnabled = !anyConnected() && !busy
        updateConnectStyle(connectButton.hasFocus())
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18),dp(16),dp(18),dp(16))
        background = GradientDrawable().apply { cornerRadius=dp(14).toFloat(); setColor(Color.rgb(15,23,42)); setStroke(dp(1),Color.rgb(51,65,85)) }
    }
    private fun sectionTitle(t:String)=TextView(this).apply { text=t; textSize=16f; setTextColor(Color.WHITE); setTypeface(typeface,Typeface.BOLD) }
    private fun protocolRadio(t:String)=RadioButton(this).apply { text=t; textSize=16f; setTextColor(Color.WHITE); gravity=Gravity.CENTER_VERTICAL; isFocusable=true; setPadding(dp(8),0,dp(8),0) }
    private fun smallRadio(t:String)=RadioButton(this).apply { text=t; textSize=14f; setTextColor(Color.WHITE); gravity=Gravity.CENTER_VERTICAL; isFocusable=true }
    private fun updateConnectStyle(focused:Boolean) { if(!::connectButton.isInitialized)return; connectButton.background=GradientDrawable().apply { cornerRadius=dp(14).toFloat(); setColor(if(anyConnected()) Color.rgb(185,28,28) else Color.rgb(234,88,12)); setStroke(dp(if(focused)4 else 1), if(focused) Color.rgb(250,204,21) else Color.rgb(249,115,22)) } }
    private fun lp(w:Int,h:Int)=LinearLayout.LayoutParams(w,h)
    private fun spacedLp()=LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(12) }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
