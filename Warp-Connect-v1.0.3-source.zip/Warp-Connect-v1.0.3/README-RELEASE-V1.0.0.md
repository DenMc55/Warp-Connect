# Warp Connect v1.0.0

Final dual-ABI release baseline based on v0.3.12.

Release changes only:
- release APK instead of debug APK
- R8 code shrinking/optimisation enabled
- Android resource shrinking enabled
- unused WorkManager dependency removed
- both arm64-v8a and armeabi-v7a retained in one APK
- conservative keep rules for WireGuard and Usque/gomobile bridges
- permanent signing expected from GitHub repository secrets

No VPN, UI, boot, protocol-selection or auto-connect behaviour is intentionally changed.
