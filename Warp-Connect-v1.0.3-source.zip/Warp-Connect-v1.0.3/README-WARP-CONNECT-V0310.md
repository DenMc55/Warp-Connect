# Warp Connect v0.3.10

UI polish only, based on the working v0.3.9 networking baseline.

- Warm yellow D-pad focus outline replaces ice-white/blue focus.
- Focused card fill is slightly calmer/darker blue.
- Connect button uses a deeper orange so action and focus colours are clearly different.
- Launcher/adaptive icon is enlarged modestly (8%) from v0.3.9 to correct the over-reduced mark.
- No networking, MASQUE isolation, WireGuard, boot, auto-connect, or layout logic changes.
