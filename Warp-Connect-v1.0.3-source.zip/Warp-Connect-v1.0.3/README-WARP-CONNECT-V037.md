# Warp Connect v0.3.7

UI/branding refinement based directly on the working v0.3.6 baseline.

Changes only:
- Fire TV layout rebalanced for 16:9 without scrolling.
- Phone/tablet layout and networking behaviour retained from v0.3.6.
- Strong D-pad focus treatment retained.
- Globe/orbit branding used for all launcher icon densities and adaptive icon foreground.
- No WireGuard, MASQUE, process-isolation, boot, or auto-connect logic changes.
