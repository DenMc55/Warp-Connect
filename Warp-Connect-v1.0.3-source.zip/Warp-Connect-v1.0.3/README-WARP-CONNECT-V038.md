# Warp Connect v0.3.8

TV UI refinement based directly on the stable v0.3.7 build.

Changes in this test:
- Fire TV connection status is much larger and easier to read across the room.
- Fire TV status detail/subtext is also larger.
- Connect / Disconnect button is centred below the status block.
- Phone/tablet layout remains unchanged apart from the visible version label.
- Networking, MASQUE process isolation, WireGuard lifecycle, remembered state, and Auto Connect behaviour are unchanged.
