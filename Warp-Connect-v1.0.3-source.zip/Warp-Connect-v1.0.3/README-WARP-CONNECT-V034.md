# Warp Connect v0.3.4 test

Baseline: v0.3.3 working process-isolation build.

Changes only:
- remember last deliberate connected/disconnected state across BOOT_COMPLETED
- reconnect the same protocol after boot when last state was connected
- reconnect WireGuard with the remembered port
- label 4500 as WARP (Recommended)
- label 2408 as WARP (WARP default)
- vertical WireGuard port selector to keep labels readable on TV/phone

MASQUE remains isolated in android:process=":masque". No v0.3.1/v0.3.2 teardown or delay experiments are included.
