# Warp Connect v0.3.5

Based directly on the stable v0.3.4 architecture.

Changes:
- Auto Connect toggle: when enabled, selected protocol reconnects after every reboot regardless of previous disconnected state.
- When Auto Connect is disabled, v0.3.4 last-state restore behaviour remains.
- Protocol choice remains fully manual.
- MASQUE process isolation is unchanged.
- WireGuard lifecycle is unchanged.
- Warp TV-style blue gradient background and tightened UI.
- WireGuard ports: 4500 WARP Recommended, 2408 WARP default, 500.
