# Warp Connect v1.0.2

Based directly on v1.0.0 release.

Changes only:
- Restores Warp Go TV v1.5-style WireGuard boot auto-connect via a short-lived foreground service.
- Initial boot delay is 10 seconds (user requested).
- Waits for usable network and retries transient WireGuard startup failures.
- Opening the app gives disconnected WireGuard one immediate second-chance restore when Auto Connect/desired ON state applies.
- MASQUE startup/process isolation is unchanged.
- TV connection status panel is darker for readability.
