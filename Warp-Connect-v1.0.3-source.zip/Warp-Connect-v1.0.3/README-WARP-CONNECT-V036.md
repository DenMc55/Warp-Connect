# Warp Connect v0.3.6

UI/branding refinement based directly on the working v0.3.5 networking baseline.

Changes:
- New flat globe/orbit Warp Connect logo.
- Stronger Warp TV-style blue/orange palette.
- TV-specific compact one-screen layout with no ScrollView on television devices.
- Strong orange/yellow D-pad focus outlines for protocol, port and auto-connect controls.
- Keeps v0.3.5 MASQUE process isolation, WireGuard lifecycle and boot auto-connect logic unchanged.
