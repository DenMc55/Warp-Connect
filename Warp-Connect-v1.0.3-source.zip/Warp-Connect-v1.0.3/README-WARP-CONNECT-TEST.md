# Warp Connect v0.3.0 — clean stable-base test

Purpose: diagnose the WireGuard activity-close regression by rebuilding from the known-good Warp Go TV v1.5 WireGuard lifecycle.

## Kept from stable v1.5
- `WarpManager.kt` unchanged.
- `AppCompatActivity` main activity.
- `lifecycleScope` + `Dispatchers.IO` for WireGuard connect/disconnect.
- No `singleTask`, `REORDER_TASKS`, `moveTaskToFront`, or protocol-handover workarounds.

## Added
- Usque MASQUE service and native libraries (arm64-v8a + armeabi-v7a).
- MASQUE / WireGuard selector.
- WireGuard ports 4500 / 2408 / 500.
- Warp Connect universal TV/mobile UI.
- New neon W Warp Connect branding and launcher icon.

## Test order
1. Fresh launch, choose WireGuard, connect, disconnect, repeat.
2. Only if WireGuard stays on screen, test MASQUE.
3. Then switch protocols while disconnected.
