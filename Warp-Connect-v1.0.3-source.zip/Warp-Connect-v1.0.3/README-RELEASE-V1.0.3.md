# Warp Connect v1.0.3

TV-only visual refresh from the stable v1.0.2 baseline.

- Removed the separate dark status panel behind Connected / Disconnected.
- Slightly darkened the full TV background for clearer status text.
- Mobile UI is unchanged.
- WireGuard, MASQUE, process isolation, boot auto-connect and reconnect behaviour are unchanged from v1.0.2.
