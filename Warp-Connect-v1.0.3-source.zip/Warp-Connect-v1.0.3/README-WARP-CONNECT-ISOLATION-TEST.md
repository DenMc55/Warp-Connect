# Warp Connect v0.3.3 — clean v0.3.0 process-isolation test

Baseline: Warp Connect v0.3.0 clean stable branch.

Intentional changes only:
- UsqueVpnService runs in `:masque` Android process.
- All Usque Go calls (registration, endpoint discovery, tunnel start/stop) run in that process.
- Main process receives MASQUE state by package-scoped broadcasts.
- WireGuard connect/disconnect path is unchanged from v0.3.0 / stable v1.5 lifecycle.

Test sequence:
1. WireGuard connect/disconnect.
2. MASQUE connect/disconnect.
3. WireGuard connect again.

Goal: determine whether isolating the Usque Go/native runtime prevents the post-MASQUE WireGuard activity closure.
