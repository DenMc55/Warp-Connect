package com.iknalos.warpgo

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private data class AppEntry(
        val packageName: String,
        val label: String,
        val info: ApplicationInfo
    )

    private val selected = linkedSetOf<String>()
    private var allApps: List<AppEntry> = emptyList()
    private lateinit var content: LinearLayout
    private lateinit var search: EditText
    private lateinit var countText: TextView
    private var query: String = ""
    private var packageToTile = mutableMapOf<String, View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected += ExclusionPreferences.get(this)
        allApps = loadUserApps()
        val visiblePackages = allApps.mapTo(hashSetOf()) { it.packageName }
        if (selected.retainAll(visiblePackages)) ExclusionPreferences.set(this, selected)
        buildUi()
        renderApps()
    }

    private fun buildUi() {
        val isTv = isTv()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(if (isTv) 34 else 18), dp(18), dp(if (isTv) 34 else 18), dp(18))
            setBackgroundResource(if (isTv) R.drawable.tv_background_tv_dark else R.drawable.tv_background)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBlock.addView(TextView(this).apply {
            text = "Exclude apps from WARP"
            textSize = if (isTv) 26f else 22f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        countText = TextView(this).apply {
            textSize = if (isTv) 14f else 12.5f
            setTextColor(Color.rgb(194, 214, 235))
        }
        titleBlock.addView(countText)
        header.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))

        val done = actionButton("DONE", isTv).apply { setOnClickListener { finish() } }
        header.addView(done, LinearLayout.LayoutParams(dp(if (isTv) 138 else 96), dp(if (isTv) 48 else 44)))
        root.addView(header)

        root.addView(TextView(this).apply {
            text = "Selected highlighted apps bypass Warp Connect"
            textSize = if (isTv) 13.5f else 12.5f
            setTextColor(Color.rgb(205, 218, 233))
            setPadding(0, dp(8), 0, dp(10))
        })

        search = EditText(this).apply {
            id = View.generateViewId()
            hint = "Search apps"
            setHintTextColor(Color.rgb(154, 181, 209))
            setTextColor(Color.WHITE)
            textSize = if (isTv) 17f else 16f
            isSingleLine = true
            isFocusable = true
            isFocusableInTouchMode = true
            setPadding(dp(14), 0, dp(14), 0)
            background = searchBackground(false)
            setOnFocusChangeListener { v, focused ->
                v.background = searchBackground(focused)
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    query = s?.toString()?.trim().orEmpty()
                    renderApps()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        done.nextFocusDownId = search.id
        root.addView(search, LinearLayout.LayoutParams(-1, dp(if (isTv) 50 else 48)).apply { bottomMargin = dp(12) })

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isFocusable = false
            addView(content, ViewGroup.LayoutParams(-1, -2))
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun renderApps(focusPackage: String? = null) {
        if (!::content.isInitialized) return
        content.removeAllViews()
        packageToTile = mutableMapOf()

        val q = query.lowercase()
        val visible = if (q.isBlank()) allApps else allApps.filter {
            it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
        }
        val excluded = visible.filter { it.packageName in selected }
        val included = visible.filterNot { it.packageName in selected }

        addSection("Excluded", excluded, showEmpty = true, topSection = excluded.isNotEmpty())
        addDivider()
        addSection("Included", included, showEmpty = true, topSection = excluded.isEmpty())
        updateCount()

        val firstTile = packageToTile.values.firstOrNull()
        search.nextFocusDownId = firstTile?.id ?: View.NO_ID

        if (focusPackage != null) {
            packageToTile[focusPackage]?.post { packageToTile[focusPackage]?.requestFocus() }
        }
    }

    private fun addSection(title: String, apps: List<AppEntry>, showEmpty: Boolean, topSection: Boolean) {
        val isTv = isTv()
        content.addView(TextView(this).apply {
            text = title
            textSize = if (isTv) 17f else 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(4), 0, dp(6))
        })

        if (apps.isEmpty()) {
            if (showEmpty) {
                content.addView(TextView(this).apply {
                    text = if (title == "Excluded") "No apps excluded" else "No apps included"
                    textSize = if (isTv) 13f else 12f
                    setTextColor(Color.rgb(160, 184, 209))
                    setPadding(dp(8), 0, 0, dp(10))
                })
            }
            return
        }

        val grid = GridLayout(this).apply {
            columnCount = if (isTv) 5 else 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        val columns = grid.columnCount
        val sidePaddingDp = if (isTv) 68 else 36
        val availableDp = (resources.configuration.screenWidthDp - sidePaddingDp).coerceAtLeast(280)
        val tileWidthDp = ((availableDp - (columns * 8)) / columns).coerceAtLeast(if (isTv) 120 else 66)
        val tileWidth = dp(tileWidthDp)
        val tileHeight = dp(if (isTv) 116 else 104)

        apps.forEachIndexed { index, app ->
            val tile = appTile(app, isTv).apply {
                id = View.generateViewId()
                if (topSection && index < columns) nextFocusUpId = search.id
            }
            packageToTile[app.packageName] = tile
            val lp = GridLayout.LayoutParams().apply {
                width = tileWidth
                height = tileHeight
                columnSpec = GridLayout.spec(index % columns)
                rowSpec = GridLayout.spec(index / columns)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(tile, lp)
        }
        content.addView(grid, LinearLayout.LayoutParams(-1, -2))
    }

    private fun addDivider() {
        content.addView(View(this).apply {
            setBackgroundColor(Color.argb(145, 84, 137, 187))
        }, LinearLayout.LayoutParams(-1, dp(1)).apply {
            topMargin = dp(10)
            bottomMargin = dp(12)
            marginStart = dp(4)
            marginEnd = dp(4)
        })
    }

    private fun appTile(app: AppEntry, isTv: Boolean): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(7), dp(6), dp(5))
            isClickable = true
            isFocusable = true
            isFocusableInTouchMode = false
            contentDescription = app.label
        }
        val icon = ImageView(this).apply {
            setImageDrawable(runCatching { packageManager.getApplicationIcon(app.info) }.getOrNull())
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        val label = TextView(this).apply {
            textSize = if (isTv) 12.5f else 10.5f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(2), dp(4), dp(2), 0)
        }
        tile.addView(icon, LinearLayout.LayoutParams(dp(if (isTv) 54 else 44), dp(if (isTv) 54 else 44)))
        tile.addView(label, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refresh(focused: Boolean) {
            val excluded = app.packageName in selected
            label.text = if (excluded) "✓ ${app.label}" else app.label
            tile.background = rounded(
                if (excluded) Color.argb(225, 22, 70, 111) else Color.argb(190, 7, 43, 82),
                when {
                    focused -> Color.rgb(255, 213, 74)
                    excluded -> Color.rgb(246, 130, 31)
                    else -> Color.rgb(40, 104, 166)
                },
                dp(11),
                if (focused || excluded) 3 else 1
            )
        }
        tile.setOnFocusChangeListener { _, focused -> refresh(focused) }
        tile.setOnClickListener {
            if (!selected.add(app.packageName)) selected.remove(app.packageName)
            ExclusionPreferences.set(this, selected)
            renderApps(app.packageName)
        }
        refresh(false)
        return tile
    }

    private fun loadUserApps(): List<AppEntry> {
        val pm = packageManager
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        )
        val byPackage = linkedMapOf<String, ApplicationInfo>()
        intents.forEach { intent ->
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0).forEach { ri ->
                val info = ri.activityInfo?.applicationInfo ?: return@forEach
                if (info.packageName != packageName) byPackage[info.packageName] = info
            }
        }
        return byPackage.values.map { info ->
            AppEntry(info.packageName, pm.getApplicationLabel(info).toString(), info)
        }.sortedBy { it.label.lowercase() }
    }

    private fun updateCount() {
        if (::countText.isInitialized) {
            countText.text = when (selected.size) {
                0 -> "No apps excluded"
                1 -> "1 app excluded"
                else -> "${selected.size} apps excluded"
            }
        }
    }

    private fun actionButton(label: String, isTv: Boolean) = TextView(this).apply {
        id = View.generateViewId()
        text = label
        textSize = if (isTv) 15f else 14f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        isFocusable = true
        isClickable = true
        background = rounded(Color.rgb(232, 101, 24), Color.rgb(247, 132, 45), dp(24), 1)
        setOnFocusChangeListener { v, focused ->
            v.background = rounded(
                Color.rgb(232, 101, 24),
                if (focused) Color.rgb(255, 213, 74) else Color.rgb(247, 132, 45),
                dp(24),
                if (focused) 4 else 1
            )
        }
    }

    private fun searchBackground(focused: Boolean) = rounded(
        Color.argb(220, 8, 45, 84),
        if (focused) Color.rgb(255, 213, 74) else Color.rgb(50, 112, 171),
        dp(10),
        if (focused) 4 else 1
    )

    private fun rounded(fill: Int, stroke: Int, radius: Int, strokeWidth: Int) = GradientDrawable().apply {
        cornerRadius = radius.toFloat()
        setColor(fill)
        setStroke(dp(strokeWidth), stroke)
    }

    private fun isTv(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
