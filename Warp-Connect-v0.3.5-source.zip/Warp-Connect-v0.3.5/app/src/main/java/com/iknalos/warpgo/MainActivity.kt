package com.iknalos.warpgo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Warp Connect clean baseline.
 *
 * WireGuard connect/disconnect intentionally follows the known-good Warp Go TV v1.5
 * AppCompatActivity + lifecycleScope flow. MASQUE is added alongside it as a separate
 * transport; there are no task/foreground/singleTask workarounds in this build.
 */
class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("warp_connect", MODE_PRIVATE) }
    private val configFile by lazy { File(filesDir, "usque-config.json") }

    private var busy = false
    private var pendingProtocol: String? = null

    @Volatile private var masqueActive = false
    @Volatile private var masqueConnected = false
    @Volatile private var masqueEndpoint = "162.159.198.2:500"

    private val masqueStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != UsqueVpnService.ACTION_STATUS) return
            when (intent.getStringExtra(UsqueVpnService.EXTRA_STATE).orEmpty()) {
                "connecting" -> { masqueActive = true; masqueConnected = false }
                "connected" -> { masqueActive = true; masqueConnected = true }
                "stopping" -> { masqueActive = true; masqueConnected = false }
                "disconnected", "error" -> { masqueActive = false; masqueConnected = false }
            }
            intent.getStringExtra(UsqueVpnService.EXTRA_ENDPOINT)?.takeIf { it.isNotBlank() }?.let { masqueEndpoint = it }
            refreshState()
        }
    }

    private lateinit var statusDot: TextView
    private lateinit var statusText: TextView
    private lateinit var detailText: TextView
    private lateinit var connectButton: TextView
    private lateinit var protocolGroup: RadioGroup
    private lateinit var masqueRadio: RadioButton
    private lateinit var wireGuardRadio: RadioButton
    private lateinit var portSection: LinearLayout
    private lateinit var portGroup: RadioGroup
    private lateinit var port4500: RadioButton
    private lateinit var port2408: RadioButton
    private lateinit var port500: RadioButton
    private lateinit var autoConnectSwitch: SwitchCompat

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                startSelected()
            } else {
                busy = false
                pendingProtocol = null
                toast("VPN permission was not granted")
                refreshState()
            }
        }

    private val ticker = object : Runnable {
        override fun run() {
            refreshState()
            handler.postDelayed(this, 750L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val filter = IntentFilter(UsqueVpnService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(masqueStatusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(masqueStatusReceiver, filter)
        }
        buildUi()
        restoreChoice()
        queryMasqueStatus()
        refreshState()
        handler.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        if (::connectButton.isInitialized) refreshState()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        runCatching { unregisterReceiver(masqueStatusReceiver) }
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(14), dp(24), dp(26))
            setBackgroundResource(R.drawable.tv_background)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        // New Warp Connect branding. A compact height keeps it usable on TV and foldables.
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.warp_connect_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "Warp Connect"
        }, LinearLayout.LayoutParams(-1, dp(132)).apply { bottomMargin = dp(2) })

        val statusCard = card()
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        statusDot = TextView(this).apply {
            text = "●"
            textSize = 22f
            setPadding(0, 0, dp(10), 0)
        }
        statusText = TextView(this).apply {
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        }
        statusRow.addView(statusDot)
        statusRow.addView(statusText)
        statusCard.addView(statusRow, lp(-1, -2))

        detailText = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(148, 163, 184))
            setPadding(0, dp(7), 0, 0)
        }
        statusCard.addView(detailText, lp(-1, -2))
        root.addView(statusCard, spacedLp())

        val protocolCard = card()
        protocolCard.addView(sectionTitle("Protocol"), lp(-1, -2))
        protocolGroup = RadioGroup(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(7), 0, 0)
        }
        masqueRadio = protocolRadio("MASQUE")
        wireGuardRadio = protocolRadio("WireGuard")
        protocolGroup.addView(masqueRadio, LinearLayout.LayoutParams(0, dp(50), 1f))
        protocolGroup.addView(wireGuardRadio, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(10) })
        protocolCard.addView(protocolGroup, lp(-1, -2))
        root.addView(protocolCard, spacedLp())

        val autoCard = card()
        val autoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val autoText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        autoText.addView(sectionTitle("Auto Connect"), lp(-1, -2))
        autoText.addView(TextView(this).apply {
            text = "Always connect the selected protocol after reboot"
            textSize = 12.5f
            setTextColor(Color.rgb(186, 202, 221))
            setPadding(0, dp(3), dp(12), 0)
        }, lp(-1, -2))
        autoRow.addView(autoText, LinearLayout.LayoutParams(0, -2, 1f))
        autoConnectSwitch = SwitchCompat(this).apply {
            isFocusable = true
            isChecked = prefs.getBoolean("auto_connect", false)
            contentDescription = "Auto Connect"
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("auto_connect", checked).apply()
            }
        }
        autoRow.addView(autoConnectSwitch, LinearLayout.LayoutParams(-2, dp(52)))
        autoCard.addView(autoRow, lp(-1, -2))
        root.addView(autoCard, spacedLp())

        portSection = card().apply {
            addView(sectionTitle("WireGuard port"), lp(-1, -2))
        }
        portGroup = RadioGroup(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, 0)
        }
        port4500 = smallRadio("4500   WARP  ·  Recommended")
        port2408 = smallRadio("2408   WARP  ·  WARP default")
        port500 = smallRadio("500")
        portGroup.addView(port4500, LinearLayout.LayoutParams(-1, dp(42)))
        portGroup.addView(port2408, LinearLayout.LayoutParams(-1, dp(42)))
        portGroup.addView(port500, LinearLayout.LayoutParams(-1, dp(42)))
        portSection.addView(portGroup, lp(-1, -2))
        root.addView(portSection, spacedLp())

        connectButton = TextView(this).apply {
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            minHeight = dp(68)
            setPadding(dp(20), dp(16), dp(20), dp(16))
            setOnClickListener { onToggle() }
            setOnFocusChangeListener { _, focused -> updateConnectStyle(focused) }
        }
        root.addView(connectButton, spacedLp())

        root.addView(TextView(this).apply {
            text = "v0.3.5 · stable dual protocol · boot auto-connect"
            textSize = 10.5f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(153, 177, 202))
            setPadding(0, dp(10), 0, 0)
        }, lp(-1, -2))

        protocolGroup.setOnCheckedChangeListener { _, _ ->
            if (!busy && !anyConnected()) {
                prefs.edit().putString("protocol", selectedProtocol()).apply()
                updateProtocolUi()
                refreshState()
            }
        }
        portGroup.setOnCheckedChangeListener { _, _ ->
            prefs.edit().putInt("port", selectedPort()).apply()
        }

        setContentView(scroll)
        connectButton.requestFocus()
    }

    private fun restoreChoice() {
        if (prefs.getString("protocol", "masque") == "wireguard") {
            wireGuardRadio.isChecked = true
        } else {
            masqueRadio.isChecked = true
        }
        when (prefs.getInt("port", 4500)) {
            2408 -> port2408.isChecked = true
            500 -> port500.isChecked = true
            else -> port4500.isChecked = true
        }
        updateProtocolUi()
    }

    private fun queryMasqueStatus() {
        runCatching {
            startService(Intent(this, UsqueVpnService::class.java).setAction(UsqueVpnService.ACTION_QUERY_STATUS))
        }
    }

    private fun selectedProtocol(): String = if (wireGuardRadio.isChecked) "wireguard" else "masque"

    private fun selectedPort(): Int = when (portGroup.checkedRadioButtonId) {
        port2408.id -> 2408
        port500.id -> 500
        else -> 4500
    }

    private fun updateProtocolUi() {
        portSection.visibility = if (selectedProtocol() == "wireguard") View.VISIBLE else View.GONE
    }

    private fun anyConnected(): Boolean = WarpManager.isUp(this) || masqueActive

    private fun onToggle() {
        if (busy) return
        if (anyConnected()) {
            if (WarpManager.isUp(this)) disconnectWireGuard() else disconnectMasque()
            return
        }

        busy = true
        pendingProtocol = selectedProtocol()
        refreshState()
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startSelected()
    }

    private fun startSelected() {
        when (pendingProtocol ?: selectedProtocol()) {
            "wireguard" -> doConnectWireGuard()
            else -> doConnectMasque()
        }
    }

    /** Exact v1.5 connection structure: lifecycleScope + Dispatchers.IO + WarpManager.connect. */
    private fun doConnectWireGuard() {
        val port = selectedPort()
        prefs.edit().putInt("port", port).apply()
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    WarpManager.connect(applicationContext, port)
                }
                prefs.edit()
                    .putBoolean("desired_connected", true)
                    .putString("protocol", "wireguard")
                    .putInt("port", port)
                    .apply()
            } catch (e: Exception) {
                toast("WireGuard failed: ${e.message ?: "unknown error"}")
            } finally {
                busy = false
                pendingProtocol = null
                refreshState()
                connectButton.requestFocus()
            }
        }
    }

    /** Exact v1.5 disconnection structure. */
    private fun disconnectWireGuard() {
        busy = true
        prefs.edit().putBoolean("desired_connected", false).apply()
        refreshState()
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    WarpManager.disconnect(applicationContext)
                }
            } catch (e: Exception) {
                toast("WireGuard disconnect failed: ${e.message ?: "unknown error"}")
            } finally {
                busy = false
                refreshState()
                connectButton.requestFocus()
            }
        }
    }

    private fun doConnectMasque() {
        masqueActive = true
        masqueConnected = false
        prefs.edit()
            .putBoolean("desired_connected", true)
            .putString("protocol", "masque")
            .apply()
        runCatching {
            startService(
                Intent(this, UsqueVpnService::class.java)
                    .putExtra("configPath", configFile.absolutePath)
                    .putExtra("sni", "www.visa.cn")
                    .putExtra("splitMode", false)
            )
        }.onFailure {
            masqueActive = false
            prefs.edit().putBoolean("desired_connected", false).apply()
            toast("MASQUE failed: ${it.message ?: "unknown error"}")
        }
        busy = false
        pendingProtocol = null
        refreshState()
        connectButton.requestFocus()
    }

    private fun disconnectMasque() {
        busy = true
        prefs.edit().putBoolean("desired_connected", false).apply()
        refreshState()
        runCatching {
            startService(Intent(this, UsqueVpnService::class.java).setAction(UsqueVpnService.ACTION_STOP))
        }
        handler.postDelayed({
            busy = false
            refreshState()
            connectButton.requestFocus()
        }, 400L)
    }

    private fun refreshState() {
        if (!::statusText.isInitialized) return
        val wg = WarpManager.isUp(this)
        val mqConnected = masqueConnected
        val mqActive = masqueActive
        val connected = wg || mqConnected
        val connecting = busy || (mqActive && !mqConnected)

        statusDot.setTextColor(
            when {
                connected -> Color.rgb(52, 211, 153)
                connecting -> Color.rgb(251, 191, 36)
                else -> Color.rgb(248, 113, 113)
            }
        )
        statusText.text = when {
            connected -> "Connected"
            connecting -> "Connecting…"
            else -> "Disconnected"
        }
        detailText.text = when {
            wg -> "WireGuard · port ${selectedPort()}"
            mqConnected -> "MASQUE · $masqueEndpoint"
            mqActive -> "MASQUE tunnel starting"
            else -> "Ready · ${if (selectedProtocol() == "masque") "MASQUE" else "WireGuard"} selected"
        }
        connectButton.text = if (wg || mqActive || mqConnected) "DISCONNECT" else "CONNECT"

        val allowProtocolChange = !anyConnected() && !busy
        autoConnectSwitch.isEnabled = !busy
        protocolGroup.isEnabled = allowProtocolChange
        masqueRadio.isEnabled = allowProtocolChange
        wireGuardRadio.isEnabled = allowProtocolChange
        port4500.isEnabled = allowProtocolChange
        port2408.isEnabled = allowProtocolChange
        port500.isEnabled = allowProtocolChange
        updateConnectStyle(connectButton.hasFocus())
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(14))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.argb(228, 9, 35, 65))
            setStroke(dp(1), Color.rgb(33, 84, 128))
        }
    }

    private fun sectionTitle(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 16f
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun protocolRadio(textValue: String): RadioButton = RadioButton(this).apply {
        text = textValue
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        isFocusable = true
        setPadding(dp(8), 0, dp(8), 0)
    }

    private fun smallRadio(textValue: String): RadioButton = RadioButton(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        isFocusable = true
    }

    private fun updateConnectStyle(focused: Boolean) {
        if (!::connectButton.isInitialized) return
        connectButton.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(if (anyConnected()) Color.rgb(185, 28, 28) else Color.rgb(30, 64, 175))
            setStroke(
                dp(if (focused) 4 else 1),
                if (focused) Color.rgb(250, 204, 21) else Color.rgb(59, 130, 246)
            )
        }
    }

    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
    private fun spacedLp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(textValue: String) = Toast.makeText(this, textValue, Toast.LENGTH_LONG).show()
}
