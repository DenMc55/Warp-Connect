# Warp Connect v1.0.6

Built directly from the stable v1.0.4 benchmark.

## Change
- Adds Settings > Exclude apps from WARP.
- Lists launchable non-system apps only.
- TV: five-column focusable grid; phone/tablet: four-column grid.
- Search bar filters by app name or package name.
- Selections save immediately and apply on the next VPN connection.
- The same exclusion list is applied to WireGuard and MASQUE.

## Unchanged from v1.0.4
- WireGuard boot auto-connect behaviour.
- MASQUE boot behaviour (the v1.0.5 startup experiment is not included).
- MASQUE `:masque` process isolation.
- Existing TV/main-screen layout and connection logic, apart from the Settings entry point.
- arm64-v8a + armeabi-v7a universal APK.
