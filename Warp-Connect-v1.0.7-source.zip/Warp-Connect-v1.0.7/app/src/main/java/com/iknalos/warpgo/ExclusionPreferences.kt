package com.iknalos.warpgo

import android.content.Context

/** Shared split-tunnel exclusion list used by both WireGuard and MASQUE. */
object ExclusionPreferences {
    private const val PREFS = "warp_connect"
    private const val KEY_EXCLUDED_APPS = "excluded_apps"

    fun get(context: Context): Set<String> =
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_EXCLUDED_APPS, emptySet())
            ?.toSet()
            ?: emptySet()

    fun set(context: Context, packages: Set<String>) {
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_EXCLUDED_APPS, packages.toSet())
            .apply()
    }
}
