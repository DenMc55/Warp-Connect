package com.iknalos.warpgo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Fire TV/Android startup reconnect helper for WireGuard.
 *
 * This deliberately mirrors the proven Warp Go TV v1.5 boot sequence, with
 * the user-requested 10-second initial delay. Missing network availability does
 * not consume a WARP retry, and transient tunnel setup failures are retried.
 * MASQUE remains entirely separate in UsqueVpnService (:masque process).
 */
class AutoConnectService : Service() {

    private val serviceJob: Job = SupervisorJob()
    private val scope = CoroutineScope(serviceJob + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(
            NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle("Warp Connect")
                .setContentText("Waiting to restore WireGuard…")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        scope.launch {
            try {
                delay(INITIAL_DELAY_MS)

                if (!shouldRestoreWireGuard()) return@launch
                if (WarpManager.isUp(applicationContext)) return@launch
                if (VpnService.prepare(applicationContext) != null) return@launch

                repeat(MAX_ATTEMPTS) { attempt ->
                    if (!shouldRestoreWireGuard()) return@launch
                    if (WarpManager.isUp(applicationContext)) return@launch

                    // Fire OS may deliver BOOT_COMPLETED before Wi-Fi is useful.
                    if (!waitForUsableNetwork(NETWORK_WAIT_TIMEOUT_MS)) return@launch

                    try {
                        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        val port = prefs.getInt(KEY_PORT, 4500)
                        WarpManager.connect(applicationContext, port, ExclusionPreferences.get(applicationContext))
                        if (WarpManager.isUp(applicationContext)) return@launch
                    } catch (t: Throwable) {
                        Log.w(TAG, "WireGuard boot attempt ${attempt + 1} failed", t)
                    }

                    if (attempt < MAX_ATTEMPTS - 1) delay(RETRY_DELAY_MS)
                }
            } finally {
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun shouldRestoreWireGuard(): Boolean {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val autoConnect = prefs.getBoolean(KEY_AUTO_CONNECT, false)
        val desiredConnected = prefs.getBoolean(KEY_DESIRED_CONNECTED, false)
        val protocol = prefs.getString(KEY_PROTOCOL, "masque")
        return protocol == "wireguard" && (autoConnect || desiredConnected)
    }

    private suspend fun waitForUsableNetwork(timeoutMs: Long): Boolean {
        var waited = 0L
        while (waited <= timeoutMs) {
            if (hasUsableNetwork(applicationContext)) return true
            delay(NETWORK_POLL_MS)
            waited += NETWORK_POLL_MS
        }
        return false
    }

    private fun hasUsableNetwork(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Warp Connect auto-connect",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Warp Connect alive briefly after boot while WireGuard is restored."
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        private const val TAG = "WarpConnectAuto"
        private const val PREFS = "warp_connect"
        private const val KEY_AUTO_CONNECT = "auto_connect"
        private const val KEY_DESIRED_CONNECTED = "desired_connected"
        private const val KEY_PROTOCOL = "protocol"
        private const val KEY_PORT = "port"

        private const val CHANNEL_ID = "warp_connect_boot"
        private const val NOTIFICATION_ID = 4500
        private const val INITIAL_DELAY_MS = 10_000L
        private const val RETRY_DELAY_MS = 10_000L
        private const val MAX_ATTEMPTS = 6
        private const val NETWORK_POLL_MS = 2_000L
        private const val NETWORK_WAIT_TIMEOUT_MS = 90_000L
    }
}
