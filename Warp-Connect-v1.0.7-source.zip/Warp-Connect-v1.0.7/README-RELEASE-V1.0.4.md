# Warp Connect v1.0.4

UI-only polish based directly on the working v1.0.3 release.

TV changes only:
- Wider Connect / Disconnect button spanning the TV content width.
- Fully rounded pill ends on the TV action button.
- Slightly larger Connected / Connecting / Disconnected status dot.

Unchanged:
- WireGuard networking and boot auto-connect logic.
- MASQUE process isolation and networking.
- Protocol / port behaviour.
- Phone / tablet UI.
- Release signing and universal arm64-v8a + armeabi-v7a packaging.
