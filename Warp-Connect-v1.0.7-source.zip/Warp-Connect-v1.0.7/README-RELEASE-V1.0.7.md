# Warp Connect v1.0.7

Built directly from the v1.0.4 stable tunnel baseline plus the app-exclusion feature introduced in v1.0.6.

Changes from v1.0.6:
- Exclude-app picker now shows all launchable user-facing apps, including preinstalled/updated-system apps such as Prime Video.
- Hidden Android/Fire OS services remain excluded because only launcher/Leanback launcher activities are listed.
- Search remains available.
- TV uses five columns and phone/tablet uses four columns.
- Explanatory text simplified to: Selected highlighted apps bypass Warp Connect.
- Tunnel, boot and auto-connect logic remains the v1.0.4 baseline.
