package com.iknalos.warpgo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.util.Log
import java.io.File
import java.util.concurrent.Executors

/**
 * Restores the user's last deliberate VPN state after a full device reboot.
 *
 * v0.3.3 process isolation is preserved:
 * - WireGuard is restored in the normal app process.
 * - MASQUE is restored only by starting UsqueVpnService, which remains in :masque.
 */
class BootReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "WarpConnectBoot"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences("warp_connect", Context.MODE_PRIVATE)
        val autoConnect = prefs.getBoolean("auto_connect", false)
        val desiredConnected = prefs.getBoolean("desired_connected", false)
        if (!autoConnect && !desiredConnected) {
            Log.i(TAG, "auto-connect off and last state disconnected; nothing to restore")
            return
        }
        Log.i(TAG, if (autoConnect) "auto-connect enabled; restoring selected protocol" else "restoring last connected state")

        // Android normally preserves VPN consent across reboot. If the user revoked
        // consent, do not open an Activity from boot; wait for the next manual launch.
        if (VpnService.prepare(context) != null) {
            Log.w(TAG, "VPN permission is not currently granted; restore skipped")
            return
        }

        when (prefs.getString("protocol", "masque")) {
            "wireguard" -> restoreWireGuard(context, prefs.getInt("port", 4500))
            else -> restoreMasque(context)
        }
    }

    private fun restoreWireGuard(context: Context, port: Int) {
        val pending = goAsync()
        Executors.newSingleThreadExecutor().execute {
            try {
                Log.i(TAG, "restoring WireGuard on port $port")
                WarpManager.connect(context.applicationContext, port)
            } catch (t: Throwable) {
                Log.e(TAG, "WireGuard boot restore failed", t)
            } finally {
                pending.finish()
            }
        }
    }

    private fun restoreMasque(context: Context) {
        val serviceIntent = Intent(context, UsqueVpnService::class.java)
            .putExtra("configPath", File(context.filesDir, "usque-config.json").absolutePath)
            .putExtra("sni", "www.visa.cn")
            .putExtra("splitMode", false)

        try {
            Log.i(TAG, "restoring MASQUE in isolated process")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "MASQUE boot restore failed", t)
        }
    }
}
