# Warp Connect v1.0.1

Release maintenance update based directly on v1.0.0.

Changes:
- WireGuard Auto Connect waits 10 seconds after BOOT_COMPLETED before starting.
- Opening Warp Connect while Auto Connect is enabled gives the selected protocol an immediate reconnect opportunity if it is disconnected.
- MASQUE process isolation, tunnel implementations, UI, dual ABI packaging and release signing remain unchanged.
