package com.warpconnect.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import usqueandroid.Usqueandroid
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    companion object { private const val REQ_VPN = 1001 }

    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val configFile by lazy { File(filesDir, "config.json") }

    private lateinit var statusDot: TextView
    private lateinit var statusText: TextView
    private lateinit var detailText: TextView
    private lateinit var connectButton: TextView

    private var vpnGranted = false
    private var requestedStart = false

    private val stateTicker = object : Runnable {
        override fun run() {
            refreshState()
            handler.postDelayed(this, 750)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Warp Connect"
        buildUi()
        refreshState()
        handler.post(stateTicker)
    }

    override fun onDestroy() {
        handler.removeCallbacks(stateTicker)
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(Color.rgb(7, 15, 28))
        }

        val title = TextView(this).apply {
            text = "Warp Connect"
            textSize = 34f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Cloudflare WARP via MASQUE"
            textSize = 15f
            setTextColor(Color.rgb(158, 174, 197))
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(30))
        }

        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        statusDot = TextView(this).apply {
            text = "●"
            textSize = 24f
            setPadding(0, 0, dp(10), 0)
        }
        statusText = TextView(this).apply {
            textSize = 23f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        }
        statusRow.addView(statusDot)
        statusRow.addView(statusText)

        detailText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(158, 174, 197))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(28))
        }

        connectButton = TextView(this).apply {
            textSize = 24f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            minHeight = dp(72)
            setPadding(dp(34), dp(18), dp(34), dp(18))
            setOnClickListener {
                if (UsqueVpnService.isTunnelActive()) disconnect() else connect()
            }
            setOnFocusChangeListener { _, focused -> updateButtonBackground(focused) }
        }
        updateButtonBackground(false)

        val footer = TextView(this).apply {
            text = "Experimental build • Usque MASQUE core"
            textSize = 12f
            setTextColor(Color.rgb(101, 120, 148))
            gravity = Gravity.CENTER
            setPadding(0, dp(34), 0, 0)
        }

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(statusRow, LinearLayout.LayoutParams(-1, -2))
        root.addView(detailText, LinearLayout.LayoutParams(-1, -2))
        root.addView(connectButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        connectButton.requestFocus()
    }

    private fun updateButtonBackground(focused: Boolean) {
        connectButton.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(if (UsqueVpnService.isTunnelActive()) Color.rgb(151, 45, 55) else Color.rgb(30, 94, 183))
            setStroke(dp(if (focused) 4 else 2), if (focused) Color.rgb(255, 176, 32) else Color.rgb(57, 119, 207))
        }
    }

    private fun refreshState() {
        if (!::statusText.isInitialized) return
        val active = UsqueVpnService.isTunnelActive()
        val connected = UsqueVpnService.isTunnelConnected()
        statusDot.setTextColor(if (connected) Color.rgb(56, 201, 115) else if (active) Color.rgb(255, 176, 32) else Color.rgb(220, 75, 75))
        statusText.text = when {
            connected -> "Connected"
            active -> "Connecting…"
            requestedStart -> "Preparing…"
            else -> "Disconnected"
        }
        detailText.text = when {
            connected -> "MASQUE • ${UsqueVpnService.currentEndpoint()}"
            active -> "Starting MASQUE tunnel"
            requestedStart -> "Registering / requesting VPN permission"
            else -> "Ready"
        }
        connectButton.text = if (active || connected) "DISCONNECT" else "CONNECT"
        updateButtonBackground(connectButton.hasFocus())
    }

    private fun hasValidRegistration(): Boolean =
        configFile.exists() && runCatching { Usqueandroid.isRegistered(configFile.absolutePath) }.getOrDefault(false)

    private fun connect() {
        requestedStart = true
        refreshState()
        if (!hasValidRegistration()) {
            executor.execute {
                try {
                    if (configFile.exists() && !hasValidRegistration()) runCatching { configFile.delete() }
                    val result = Usqueandroid.register(configFile.absolutePath, "Android")
                    handler.post {
                        if (result.isNullOrBlank() && hasValidRegistration()) requestVpnAndStart()
                        else {
                            requestedStart = false
                            refreshState()
                            toast("WARP registration failed${if (result.isNullOrBlank()) "" else ": $result"}")
                        }
                    }
                } catch (e: Exception) {
                    handler.post {
                        requestedStart = false
                        refreshState()
                        toast("Registration error: ${e.message ?: e.javaClass.simpleName}")
                    }
                }
            }
            return
        }
        requestVpnAndStart()
    }

    private fun requestVpnAndStart() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null && !vpnGranted) {
            startActivityForResult(prepareIntent, REQ_VPN)
            return
        }
        vpnGranted = true
        startTunnel()
    }

    private fun startTunnel() {
        requestedStart = false
        val endpoint = runCatching { Usqueandroid.getDefaultEndpoint(configFile.absolutePath) }
            .getOrNull().orEmpty().ifBlank { "162.159.198.2:500" }
        val intent = Intent(this, UsqueVpnService::class.java)
            .putExtra("configPath", configFile.absolutePath)
            .putExtra("sni", "www.visa.cn")
            .putExtra("endpoint", endpoint)
            .putExtra("splitMode", false)
        startService(intent)
        refreshState()
    }

    private fun disconnect() {
        requestedStart = false
        UsqueVpnService.stopActiveTunnel()
        runCatching { startService(Intent(this, UsqueVpnService::class.java).setAction(UsqueVpnService.ACTION_STOP)) }
        handler.postDelayed({ runCatching { stopService(Intent(this, UsqueVpnService::class.java)) }; refreshState() }, 350)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) {
            vpnGranted = true
            startTunnel()
        } else if (requestCode == REQ_VPN) {
            requestedStart = false
            refreshState()
            toast("VPN permission was not granted")
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
