# Warp Connect v0.1.0

First proof-of-concept build based on the open-source Usque Android MASQUE client.

## Goals
- One APK for Fire TV / Android TV and normal Android phones/tablets.
- Keep the Usque MASQUE backend unchanged as far as practical.
- Support both `armeabi-v7a` and `arm64-v8a` native ABIs already bundled by Usque.
- Keep `minSdk 24`.
- Use only standard Android UI widgets for maximum compatibility.
- D-pad and touch friendly.

## First-test behavior
- App name: Warp Connect
- Package: `com.warpconnect.app`
- Protocol label: MASQUE
- Default SNI: `www.visa.cn`
- Endpoint: supplied by Usque `getDefaultEndpoint()`, falling back to `162.159.198.2:500`
- First connection automatically registers a WARP account via Usque.
- Global VPN mode only in this first test.
- No boot auto-connect yet. Add only after manual connection is proven on old and new Firesticks.

## Build
The included GitHub Actions workflow can build a debug APK with JDK 17 + Gradle 8.5.
