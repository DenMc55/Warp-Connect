package com.iknalos.warpgo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Warp Connect clean baseline.
 *
 * WireGuard connect/disconnect intentionally follows the known-good Warp Go TV v1.5
 * AppCompatActivity + lifecycleScope flow. MASQUE is added alongside it as a separate
 * transport; there are no task/foreground/singleTask workarounds in this build.
 */
class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("warp_connect", MODE_PRIVATE) }
    private val configFile by lazy { File(filesDir, "usque-config.json") }

    private var busy = false
    private var pendingProtocol: String? = null

    @Volatile private var masqueActive = false
    @Volatile private var masqueConnected = false
    @Volatile private var masqueEndpoint = "162.159.198.2:500"

    private val masqueStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != UsqueVpnService.ACTION_STATUS) return
            when (intent.getStringExtra(UsqueVpnService.EXTRA_STATE).orEmpty()) {
                "connecting" -> { masqueActive = true; masqueConnected = false }
                "connected" -> { masqueActive = true; masqueConnected = true }
                "stopping" -> { masqueActive = true; masqueConnected = false }
                "disconnected", "error" -> { masqueActive = false; masqueConnected = false }
            }
            intent.getStringExtra(UsqueVpnService.EXTRA_ENDPOINT)?.takeIf { it.isNotBlank() }?.let { masqueEndpoint = it }
            refreshState()
        }
    }

    private lateinit var statusDot: TextView
    private lateinit var statusText: TextView
    private lateinit var detailText: TextView
    private lateinit var connectButton: TextView
    private lateinit var protocolGroup: RadioGroup
    private lateinit var masqueRadio: RadioButton
    private lateinit var wireGuardRadio: RadioButton
    private lateinit var portSection: LinearLayout
    private lateinit var portGroup: RadioGroup
    private lateinit var port4500: RadioButton
    private lateinit var port2408: RadioButton
    private lateinit var port500: RadioButton
    private lateinit var autoConnectSwitch: SwitchCompat

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                startSelected()
            } else {
                busy = false
                pendingProtocol = null
                toast("VPN permission was not granted")
                refreshState()
            }
        }

    private val ticker = object : Runnable {
        override fun run() {
            refreshState()
            handler.postDelayed(this, 750L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val filter = IntentFilter(UsqueVpnService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(masqueStatusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(masqueStatusReceiver, filter)
        }
        buildUi()
        restoreChoice()
        queryMasqueStatus()
        refreshState()
        handler.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        if (::connectButton.isInitialized) refreshState()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        runCatching { unregisterReceiver(masqueStatusReceiver) }
        super.onDestroy()
    }

    private fun buildUi() {
        val isTv = (resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(if (isTv) 30 else 20), dp(if (isTv) 10 else 12), dp(if (isTv) 30 else 20), dp(if (isTv) 10 else 20))
            setBackgroundResource(R.drawable.tv_background)
        }

        statusDot = TextView(this).apply {
            text = "●"
            textSize = if (isTv) 20f else 21f
            setPadding(0, 0, dp(8), 0)
        }
        statusText = TextView(this).apply {
            textSize = if (isTv) 20f else 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        }
        detailText = TextView(this).apply {
            textSize = if (isTv) 11.5f else 12.5f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(205, 218, 233))
            setPadding(0, dp(3), 0, 0)
        }
        connectButton = TextView(this).apply {
            textSize = if (isTv) 20f else 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            minHeight = dp(if (isTv) 58 else 64)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setOnClickListener { onToggle() }
            setOnFocusChangeListener { _, focused -> updateConnectStyle(focused) }
        }

        protocolGroup = RadioGroup(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        masqueRadio = protocolRadio("MASQUE", isTv)
        wireGuardRadio = protocolRadio("WireGuard", isTv)
        protocolGroup.addView(masqueRadio, LinearLayout.LayoutParams(0, dp(if (isTv) 44 else 48), 1f))
        protocolGroup.addView(wireGuardRadio, LinearLayout.LayoutParams(0, dp(if (isTv) 44 else 48), 1f).apply { marginStart = dp(8) })

        portSection = card(isTv).apply {
            addView(sectionTitle("WireGuard port", isTv), lp(-1, -2))
        }
        portGroup = RadioGroup(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(3), 0, 0)
        }
        port4500 = smallRadio("4500   WARP  ·  Recommended", isTv)
        port2408 = smallRadio("2408   WARP  ·  WARP default", isTv)
        port500 = smallRadio("500", isTv)
        val portHeight = dp(if (isTv) 38 else 42)
        portGroup.addView(port4500, LinearLayout.LayoutParams(-1, portHeight))
        portGroup.addView(port2408, LinearLayout.LayoutParams(-1, portHeight))
        portGroup.addView(port500, LinearLayout.LayoutParams(-1, portHeight))
        portSection.addView(portGroup, lp(-1, -2))

        autoConnectSwitch = SwitchCompat(this).apply {
            isFocusable = true
            isChecked = prefs.getBoolean("auto_connect", false)
            contentDescription = "Auto Connect"
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.WHITE, Color.rgb(210, 218, 228))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.rgb(246, 130, 31), Color.rgb(76, 99, 127))
            )
            setPadding(dp(10), 0, dp(10), 0)
            setOnFocusChangeListener { v, focused -> updateFocusBackground(v, focused) }
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("auto_connect", checked).apply()
            }
        }

        if (isTv) {
            // TV-first layout: everything fits on one 1080p screen without scrolling.
            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            header.addView(ImageView(this).apply {
                setImageResource(R.drawable.warp_connect_logo)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                contentDescription = "Warp Connect"
            }, LinearLayout.LayoutParams(dp(155), dp(92)))

            val statusBlock = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(16), 0, dp(16), 0)
            }
            val statusRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                addView(statusDot)
                addView(statusText)
            }
            statusBlock.addView(statusRow, lp(-1, -2))
            statusBlock.addView(detailText, lp(-1, -2))
            header.addView(statusBlock, LinearLayout.LayoutParams(0, -2, 1f))
            header.addView(connectButton, LinearLayout.LayoutParams(dp(250), dp(60)))
            root.addView(header, lp(-1, -2))

            val body = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }
            val left = card(true).apply {
                addView(sectionTitle("Protocol", true), lp(-1, -2))
                addView(protocolGroup, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                addView(portSection, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }
            body.addView(left, LinearLayout.LayoutParams(0, -2, 1.2f))

            val right = card(true).apply {
                addView(sectionTitle("Auto Connect", true), lp(-1, -2))
                addView(TextView(this@MainActivity).apply {
                    text = "Connect the selected protocol automatically after every reboot"
                    textSize = 11.5f
                    setTextColor(Color.rgb(205, 218, 233))
                    setPadding(0, dp(3), 0, dp(5))
                }, lp(-1, -2))
                addView(autoConnectSwitch, LinearLayout.LayoutParams(-1, dp(46)))
                addView(TextView(this@MainActivity).apply {
                    text = "Protocol choice remains manual"
                    textSize = 11f
                    setTextColor(Color.rgb(176, 196, 219))
                    setPadding(0, dp(5), 0, 0)
                }, lp(-1, -2))
            }
            body.addView(right, LinearLayout.LayoutParams(0, -2, 0.8f).apply { marginStart = dp(12) })
            root.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

            root.addView(TextView(this).apply {
                text = "v0.3.6 · stable dual protocol · TV UI"
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(170, 193, 218))
                setPadding(0, dp(6), 0, 0)
            }, lp(-1, -2))

            setContentView(root)
        } else {
            // Phone/tablet keeps a comfortable stacked layout and may scroll on small screens.
            val scroll = ScrollView(this).apply {
                isFillViewport = true
                addView(root)
            }
            root.addView(ImageView(this).apply {
                setImageResource(R.drawable.warp_connect_logo)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                contentDescription = "Warp Connect"
            }, LinearLayout.LayoutParams(-1, dp(128)).apply { bottomMargin = dp(2) })

            val statusCard = card(false)
            val statusRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                addView(statusDot)
                addView(statusText)
            }
            statusCard.addView(statusRow, lp(-1, -2))
            statusCard.addView(detailText, lp(-1, -2))
            root.addView(statusCard, spacedLp())

            val protocolCard = card(false).apply {
                addView(sectionTitle("Protocol", false), lp(-1, -2))
                addView(protocolGroup, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
            }
            root.addView(protocolCard, spacedLp())

            val autoCard = card(false)
            val autoRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val autoText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            autoText.addView(sectionTitle("Auto Connect", false), lp(-1, -2))
            autoText.addView(TextView(this).apply {
                text = "Always connect the selected protocol after reboot"
                textSize = 12f
                setTextColor(Color.rgb(205, 218, 233))
                setPadding(0, dp(2), dp(10), 0)
            }, lp(-1, -2))
            autoRow.addView(autoText, LinearLayout.LayoutParams(0, -2, 1f))
            autoRow.addView(autoConnectSwitch, LinearLayout.LayoutParams(-2, dp(50)))
            autoCard.addView(autoRow, lp(-1, -2))
            root.addView(autoCard, spacedLp())

            root.addView(portSection, spacedLp())
            root.addView(connectButton, spacedLp())
            root.addView(TextView(this).apply {
                text = "v0.3.6 · stable dual protocol · boot auto-connect"
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(170, 193, 218))
                setPadding(0, dp(8), 0, 0)
            }, lp(-1, -2))
            setContentView(scroll)
        }

        protocolGroup.setOnCheckedChangeListener { _, _ ->
            if (!busy && !anyConnected()) {
                prefs.edit().putString("protocol", selectedProtocol()).apply()
                updateProtocolUi()
                refreshState()
            }
        }
        portGroup.setOnCheckedChangeListener { _, _ ->
            prefs.edit().putInt("port", selectedPort()).apply()
        }

        connectButton.requestFocus()
    }

    private fun restoreChoice() {
        if (prefs.getString("protocol", "masque") == "wireguard") {
            wireGuardRadio.isChecked = true
        } else {
            masqueRadio.isChecked = true
        }
        when (prefs.getInt("port", 4500)) {
            2408 -> port2408.isChecked = true
            500 -> port500.isChecked = true
            else -> port4500.isChecked = true
        }
        updateProtocolUi()
    }

    private fun queryMasqueStatus() {
        runCatching {
            startService(Intent(this, UsqueVpnService::class.java).setAction(UsqueVpnService.ACTION_QUERY_STATUS))
        }
    }

    private fun selectedProtocol(): String = if (wireGuardRadio.isChecked) "wireguard" else "masque"

    private fun selectedPort(): Int = when (portGroup.checkedRadioButtonId) {
        port2408.id -> 2408
        port500.id -> 500
        else -> 4500
    }

    private fun updateProtocolUi() {
        portSection.visibility = if (selectedProtocol() == "wireguard") View.VISIBLE else View.GONE
    }

    private fun anyConnected(): Boolean = WarpManager.isUp(this) || masqueActive

    private fun onToggle() {
        if (busy) return
        if (anyConnected()) {
            if (WarpManager.isUp(this)) disconnectWireGuard() else disconnectMasque()
            return
        }

        busy = true
        pendingProtocol = selectedProtocol()
        refreshState()
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startSelected()
    }

    private fun startSelected() {
        when (pendingProtocol ?: selectedProtocol()) {
            "wireguard" -> doConnectWireGuard()
            else -> doConnectMasque()
        }
    }

    /** Exact v1.5 connection structure: lifecycleScope + Dispatchers.IO + WarpManager.connect. */
    private fun doConnectWireGuard() {
        val port = selectedPort()
        prefs.edit().putInt("port", port).apply()
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    WarpManager.connect(applicationContext, port)
                }
                prefs.edit()
                    .putBoolean("desired_connected", true)
                    .putString("protocol", "wireguard")
                    .putInt("port", port)
                    .apply()
            } catch (e: Exception) {
                toast("WireGuard failed: ${e.message ?: "unknown error"}")
            } finally {
                busy = false
                pendingProtocol = null
                refreshState()
                connectButton.requestFocus()
            }
        }
    }

    /** Exact v1.5 disconnection structure. */
    private fun disconnectWireGuard() {
        busy = true
        prefs.edit().putBoolean("desired_connected", false).apply()
        refreshState()
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    WarpManager.disconnect(applicationContext)
                }
            } catch (e: Exception) {
                toast("WireGuard disconnect failed: ${e.message ?: "unknown error"}")
            } finally {
                busy = false
                refreshState()
                connectButton.requestFocus()
            }
        }
    }

    private fun doConnectMasque() {
        masqueActive = true
        masqueConnected = false
        prefs.edit()
            .putBoolean("desired_connected", true)
            .putString("protocol", "masque")
            .apply()
        runCatching {
            startService(
                Intent(this, UsqueVpnService::class.java)
                    .putExtra("configPath", configFile.absolutePath)
                    .putExtra("sni", "www.visa.cn")
                    .putExtra("splitMode", false)
            )
        }.onFailure {
            masqueActive = false
            prefs.edit().putBoolean("desired_connected", false).apply()
            toast("MASQUE failed: ${it.message ?: "unknown error"}")
        }
        busy = false
        pendingProtocol = null
        refreshState()
        connectButton.requestFocus()
    }

    private fun disconnectMasque() {
        busy = true
        prefs.edit().putBoolean("desired_connected", false).apply()
        refreshState()
        runCatching {
            startService(Intent(this, UsqueVpnService::class.java).setAction(UsqueVpnService.ACTION_STOP))
        }
        handler.postDelayed({
            busy = false
            refreshState()
            connectButton.requestFocus()
        }, 400L)
    }

    private fun refreshState() {
        if (!::statusText.isInitialized) return
        val wg = WarpManager.isUp(this)
        val mqConnected = masqueConnected
        val mqActive = masqueActive
        val connected = wg || mqConnected
        val connecting = busy || (mqActive && !mqConnected)

        statusDot.setTextColor(
            when {
                connected -> Color.rgb(52, 211, 153)
                connecting -> Color.rgb(251, 191, 36)
                else -> Color.rgb(248, 113, 113)
            }
        )
        statusText.text = when {
            connected -> "Connected"
            connecting -> "Connecting…"
            else -> "Disconnected"
        }
        detailText.text = when {
            wg -> "WireGuard · port ${selectedPort()}"
            mqConnected -> "MASQUE · $masqueEndpoint"
            mqActive -> "MASQUE tunnel starting"
            else -> "Ready · ${if (selectedProtocol() == "masque") "MASQUE" else "WireGuard"} selected"
        }
        connectButton.text = if (wg || mqActive || mqConnected) "DISCONNECT" else "CONNECT"

        val allowProtocolChange = !anyConnected() && !busy
        autoConnectSwitch.isEnabled = !busy
        protocolGroup.isEnabled = allowProtocolChange
        masqueRadio.isEnabled = allowProtocolChange
        wireGuardRadio.isEnabled = allowProtocolChange
        port4500.isEnabled = allowProtocolChange
        port2408.isEnabled = allowProtocolChange
        port500.isEnabled = allowProtocolChange
        updateConnectStyle(connectButton.hasFocus())
    }

    private fun card(isTv: Boolean): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(if (isTv) 14 else 16), dp(if (isTv) 10 else 12), dp(if (isTv) 14 else 16), dp(if (isTv) 10 else 12))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.argb(214, 7, 43, 82))
            setStroke(dp(1), Color.rgb(40, 104, 166))
        }
    }

    private fun sectionTitle(textValue: String, isTv: Boolean): TextView = TextView(this).apply {
        text = textValue
        textSize = if (isTv) 15f else 16f
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun protocolRadio(textValue: String, isTv: Boolean): RadioButton = RadioButton(this).apply {
        text = textValue
        textSize = if (isTv) 15f else 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        isFocusable = true
        isFocusableInTouchMode = false
        setPadding(dp(8), 0, dp(8), 0)
        buttonTintList = radioTint()
        setOnFocusChangeListener { v, focused -> updateFocusBackground(v, focused) }
        updateFocusBackground(this, false)
    }

    private fun smallRadio(textValue: String, isTv: Boolean): RadioButton = RadioButton(this).apply {
        text = textValue
        textSize = if (isTv) 13.5f else 14f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        isFocusable = true
        isFocusableInTouchMode = false
        setPadding(dp(7), 0, dp(7), 0)
        buttonTintList = radioTint()
        setOnFocusChangeListener { v, focused -> updateFocusBackground(v, focused) }
        updateFocusBackground(this, false)
    }

    private fun radioTint() = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
        intArrayOf(Color.rgb(246, 130, 31), Color.rgb(225, 233, 242))
    )

    private fun updateFocusBackground(view: View, focused: Boolean) {
        view.background = GradientDrawable().apply {
            cornerRadius = dp(9).toFloat()
            setColor(if (focused) Color.rgb(24, 87, 145) else Color.TRANSPARENT)
            setStroke(
                dp(if (focused) 3 else 1),
                if (focused) Color.rgb(255, 177, 66) else Color.argb(90, 83, 134, 181)
            )
        }
        if (view is TextView) {
            view.setTextColor(if (focused) Color.WHITE else Color.rgb(244, 247, 251))
        }
    }

    private fun updateConnectStyle(focused: Boolean) {
        if (!::connectButton.isInitialized) return
        connectButton.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (anyConnected()) Color.rgb(201, 52, 48) else Color.rgb(246, 130, 31))
            setStroke(
                dp(if (focused) 4 else 1),
                if (focused) Color.rgb(255, 220, 110) else Color.rgb(255, 159, 61)
            )
        }
    }

    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
    private fun spacedLp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(textValue: String) = Toast.makeText(this, textValue, Toast.LENGTH_LONG).show()
}
