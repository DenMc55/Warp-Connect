package com.iknalos.warpgo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.util.Log

/**
 * Restores the user's last deliberate VPN state after a full device reboot.
 *
 * v0.3.3 process isolation is preserved:
 * - WireGuard is restored in the normal app process.
 * - MASQUE boot restore uses a small network-ready helper in the normal process.
 * - All Usque/Go work still runs only inside UsqueVpnService in :masque.
 */
class BootReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "WarpConnectBoot"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences("warp_connect", Context.MODE_PRIVATE)
        val autoConnect = prefs.getBoolean("auto_connect", false)
        val desiredConnected = prefs.getBoolean("desired_connected", false)
        if (!autoConnect && !desiredConnected) {
            Log.i(TAG, "auto-connect off and last state disconnected; nothing to restore")
            return
        }
        Log.i(TAG, if (autoConnect) "auto-connect enabled; restoring selected protocol" else "restoring last connected state")

        // Android normally preserves VPN consent across reboot. If the user revoked
        // consent, do not open an Activity from boot; wait for the next manual launch.
        if (VpnService.prepare(context) != null) {
            Log.w(TAG, "VPN permission is not currently granted; restore skipped")
            return
        }

        when (prefs.getString("protocol", "masque")) {
            "wireguard" -> restoreWireGuard(context, prefs.getInt("port", 4500))
            else -> restoreMasque(context)
        }
    }

    private fun restoreWireGuard(context: Context, port: Int) {
        // Match the proven Warp Go TV v1.5 Fire TV boot pattern: the receiver
        // only launches a short-lived foreground helper. The helper waits for
        // Fire OS networking to settle, then retries transient tunnel failures.
        Log.i(TAG, "starting delayed WireGuard restore helper on port $port")
        val serviceIntent = Intent(context, AutoConnectService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "WireGuard auto-connect helper failed to start", t)
        }
    }

    private fun restoreMasque(context: Context) {
        // Do not start Usque directly from BOOT_COMPLETED. Fire OS can report boot
        // complete before Wi-Fi is genuinely usable, which can make MASQUE spend a
        // long time recovering. The helper launches Usque at the first usable network.
        val serviceIntent = Intent(context, MasqueAutoConnectService::class.java)
        try {
            Log.i(TAG, "starting network-ready MASQUE restore helper")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "MASQUE auto-connect helper failed to start", t)
        }
    }
}
