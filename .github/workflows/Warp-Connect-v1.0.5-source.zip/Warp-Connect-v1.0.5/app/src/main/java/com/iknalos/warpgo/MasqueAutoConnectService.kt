package com.iknalos.warpgo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/**
 * Fast boot helper for MASQUE.
 *
 * BOOT_COMPLETED can arrive before Fire OS networking is genuinely usable.
 * Starting Usque too early can leave the native MASQUE setup waiting/retrying
 * for much longer than necessary. This helper stays in the normal app process,
 * waits only until the network is usable, then launches UsqueVpnService.
 * All Usque/Go work still remains isolated in the :masque process.
 */
class MasqueAutoConnectService : Service() {

    private val serviceJob: Job = SupervisorJob()
    private val scope = CoroutineScope(serviceJob + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(
            NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle("Warp Connect")
                .setContentText("Waiting to restore MASQUE…")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        scope.launch {
            try {
                if (!shouldRestoreMasque()) return@launch
                if (VpnService.prepare(applicationContext) != null) return@launch

                // No fixed startup delay. Start as soon as Fire OS networking is
                // actually ready. Prefer a validated network, but fall back after
                // a short settling period for older/quirky Fire OS builds that do
                // not promptly expose NET_CAPABILITY_VALIDATED.
                if (!waitForUsableNetwork(NETWORK_WAIT_TIMEOUT_MS)) {
                    Log.w(TAG, "MASQUE boot restore timed out waiting for network")
                    return@launch
                }

                if (!shouldRestoreMasque()) return@launch
                if (VpnService.prepare(applicationContext) != null) return@launch

                repeat(START_ATTEMPTS) { attempt ->
                    try {
                        startMasqueTunnel()
                        Log.i(TAG, "MASQUE boot restore launched on attempt ${attempt + 1}")
                        return@launch
                    } catch (t: Throwable) {
                        Log.w(TAG, "MASQUE service launch attempt ${attempt + 1} failed", t)
                        if (attempt < START_ATTEMPTS - 1) delay(START_RETRY_DELAY_MS)
                    }
                }
            } finally {
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun shouldRestoreMasque(): Boolean {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val autoConnect = prefs.getBoolean(KEY_AUTO_CONNECT, false)
        val desiredConnected = prefs.getBoolean(KEY_DESIRED_CONNECTED, false)
        val protocol = prefs.getString(KEY_PROTOCOL, "masque")
        return protocol == "masque" && (autoConnect || desiredConnected)
    }

    private suspend fun waitForUsableNetwork(timeoutMs: Long): Boolean {
        var waited = 0L
        var internetSeenFor = 0L

        while (waited <= timeoutMs) {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork
            val caps = network?.let { cm.getNetworkCapabilities(it) }
            val hasInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true

            if (hasInternet && validated) return true

            if (hasInternet) {
                internetSeenFor += NETWORK_POLL_MS
                if (internetSeenFor >= UNVALIDATED_SETTLE_MS) return true
            } else {
                internetSeenFor = 0L
            }

            delay(NETWORK_POLL_MS)
            waited += NETWORK_POLL_MS
        }
        return false
    }

    private fun startMasqueTunnel() {
        val serviceIntent = Intent(this, UsqueVpnService::class.java)
            .putExtra("configPath", File(filesDir, "usque-config.json").absolutePath)
            .putExtra("sni", "www.visa.cn")
            .putExtra("splitMode", false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Warp Connect MASQUE auto-connect",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Waits for network readiness before restoring MASQUE after boot."
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        private const val TAG = "WarpConnectMasqueAuto"
        private const val PREFS = "warp_connect"
        private const val KEY_AUTO_CONNECT = "auto_connect"
        private const val KEY_DESIRED_CONNECTED = "desired_connected"
        private const val KEY_PROTOCOL = "protocol"

        private const val CHANNEL_ID = "warp_connect_masque_boot"
        private const val NOTIFICATION_ID = 4501

        private const val NETWORK_POLL_MS = 500L
        private const val UNVALIDATED_SETTLE_MS = 5_000L
        private const val NETWORK_WAIT_TIMEOUT_MS = 90_000L
        private const val START_ATTEMPTS = 3
        private const val START_RETRY_DELAY_MS = 2_000L
    }
}
