# Warp Connect v1.0.5

Baseline: v1.0.4.

This release changes only MASQUE auto-connect startup after device reboot.

- WireGuard networking and its proven v1.5-style AutoConnectService are unchanged.
- Manual MASQUE connect/disconnect behaviour is unchanged.
- UsqueVpnService and all Usque/Go work remain isolated in `:masque`.
- The TV and mobile UI layouts are unchanged apart from the version footer.
- BOOT_COMPLETED now starts a lightweight MASQUE helper in the normal app process.
- The helper waits for an actually usable network, then immediately starts UsqueVpnService.
- There is no fixed MASQUE boot delay.
- A validated network starts immediately; Fire OS builds slow to expose VALIDATED fall back after 5 seconds of continuous INTERNET capability.

Goal: avoid starting MASQUE too early during Fire OS boot and reduce the roughly two-minute reconnect time seen on some devices.
